# Windows Admin Center

In this folder you will want to download and place the Windows Admin Center .MSI file specific to the version of Windows Server that you are deploying. At the time of writing this, [Windows Admin Center 1809](https://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/windows-admin-center) was the latest release.

