# SDNExpress - Custom

The scripts in this folder have been taken from [Microsoft SDN GitHub](https://github.com/Microsoft/SDN/tree/master/SDNExpress/scripts) and have been slightly modified to work within the limited constraints of the SDN Sandbox environment.

